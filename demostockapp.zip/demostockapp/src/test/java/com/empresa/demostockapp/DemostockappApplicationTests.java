package com.empresa.demostockapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemostockappApplicationTests {

	@Test
	void contextLoads() {
	}

}
